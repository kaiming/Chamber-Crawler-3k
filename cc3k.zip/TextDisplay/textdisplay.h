#ifndef __TEXTDISPLAY_H__
#define __TEXTDISPLAY_H__

#include <iostream>
#include "../Board/board.h"

class TextDisplay {
    private:

    public:

    void drawFloor(std::ostream& out, Board& board, std::string action); 

}; 

#endif
