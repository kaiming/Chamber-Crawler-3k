#include "enemy.h"


// constructor
Enemy::Enemy(double HP, double atk, double def) : Character {HP, atk, def} {}
